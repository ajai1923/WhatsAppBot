/*
 * Starter Project for WhatsApp Echo Bot Tutorial
 *
 * Remix this as the starting point for following the WhatsApp Echo Bot tutorial
 *
 */
"use strict";
// Access token for your app
// (copy token from DevX getting started page
// and save it as environment variable into the .env file)
const token = process.env.WHATSAPP_TOKEN;
// console.log(token);
// Imports dependencies and set up http server
const request = require("request"),
  express = require("express"),
  body_parser = require("body-parser"),
  axios = require("axios").default,
  app = express().use(body_parser.json());
  // // console.log(request);
  // console.log(body_parser);
  // console.log(axios);
  // console.log(app);
// creates express http server
var greet_flag = true;
// Sets server port and logs message on success

// app.listen(process.env.PORT || 1337, '0.0.0.0' , console.log("webhook is listening"));

// Accepts POST requests at /webhook endpoint

// const express = require('express')
// const request = require('request');

// app = express();
// const PORT = 3000;

// ############### flask connection ##############################
app.get('/home', function(req, res) {
    request('http://127.0.0.1:5000/flask', function (error, response, body) {
        console.error('error:', error); // Print the error
        console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
        console.log('body:', body); // Print the data received
        res.send(body); //Display the response on the website
      });      
});

app.listen(process.env.PORT || 1337, console.log("webhook is listening"));

// --------------------------------------------------------------------------------

// app.listen(process.env.PORT, function (){ 
//     console.log('Listening on Port 3000');
// });  


app.post("/webhook", (req, res) => {
  // app.post("/webhook", function(req, res) {
  // request('http://127.0.0.1:5000/flask', function (error, response, body) {
  //     console.error('error:', error); // Print the error
  //     console.log('statusCode:', response && response.statusCode); // Print the response status code if a response was received
  //     console.log('body:', body); // Print the data received
  //     res.send(body); //Display the response on the website
  //   });   
  // Parse the request body from the POST
  var body = req.body;
  console.log(body);
  // Check the Incoming webhook message
  console.log(JSON.stringify(req.body, null, 2));
  // info on WhatsApp text message payload: https://developers.facebook.com/docs/whatsapp/cloud-api/webhooks/payload-examples#text-messages
  if (req.body.object) {
    if (
      req.body.entry &&
      req.body.entry[0].changes &&
      req.body.entry[0].changes[0] &&
      req.body.entry[0].changes[0].value.messages &&
      req.body.entry[0].changes[0].value.messages[0]
    ) {
          // var axios = require('axios');
      
          if (req.body.entry[0].changes[0].value.messages[0].type == "image")
          {
            
            var fs = require("fs");
            var img_id = req.body.entry[0].changes[0].value.messages[0].image.id;
            console.log('img_id_is---->: '+img_id);

            console.log("image_url_data1--->: "+JSON.stringify(image_url));
            console.log("image_url_data2--->: "+image_url);

            var image_url=[];

            var image_config = {
              method: 'get',
              url: 'https://graph.facebook.com/v15.0/'+img_id,
              headers: { 
                'Authorization': 'Bearer EAATQpG7HUWUBALG4ZCqcKutVqY6ZCSePThwNijZBnRafaQTzp7Se7wgDZCbkhgKPlqPn1Aei2rZCHrFHfFontlkcPDLKn18rELdAaNeZBFynUEu4yWjBQT9bX6rwSYyJIA73ZCMZAZAIF5NmtxeT1bKETsvwP5kW9u2ZBgJM20QLl8UvV9MZCHROqZBFnvWvvOTVmb5Bxa1g2t9zmAZDZD'
              },
              // data : image_config
            };
            // image_url.push(image_config);
            
            axios(image_config).then(function (image_config) {
              // image_url.push(image_config);
              // image1.push(JSON.stringify(image_config.data));
              console.log(JSON.stringify(image_config.data));
              console.log('image_url2--->: '+JSON.stringify(image_config.data.url));
              
              var images_data = image_config.data.url
              image_url.push(images_data);
              
            })
            .catch(function (error) {
              console.log(error);
            });

            console.log("image_url_data3--->: "+JSON.stringify(image_url));
            console.log("image_url_data4--->: "+image_url);
            
              // console.log(JSON.stringify('image_url3--->: '+image_config.data.url));
              console.log('image_url3--->: '+JSON.stringify(image_url));
            
               var image_response = {
                  method: 'get',
                  url: "https://lookaside.fbsbx.com/whatsapp_business/attachments/?mid=1094660477874325&ext=1671596213&hash=ATte293t1MtMrKsYZycn4I3USS7JfNsL6Q-AVNtGkwLgqQ",
                  // url: dynamic_image_url,
                    headers: {
                    'Authorization': 'Bearer EAATQpG7HUWUBALG4ZCqcKutVqY6ZCSePThwNijZBnRafaQTzp7Se7wgDZCbkhgKPlqPn1Aei2rZCHrFHfFontlkcPDLKn18rELdAaNeZBFynUEu4yWjBQT9bX6rwSYyJIA73ZCMZAZAIF5NmtxeT1bKETsvwP5kW9u2ZBgJM20QLl8UvV9MZCHROqZBFnvWvvOTVmb5Bxa1g2t9zmAZDZD'
                  }
                };
 

               axios(image_response)
                  .then(function (image_response) {
                    console.log(JSON.stringify(typeof(image_response.data)));
                    // console.log(JSON.stringify("image_response-->: "+image_response.data));
                    // var images_res1 = JSON.stringify(image_response.data);
                    var images_res1 = image_response.data;
                     console.log("images_response1-->"+images_res1);


                    var buff = new Buffer.from(images_res1).toString("base64");
                    // console.log("response2-->: "+images_res2);
                    console.log("image_type--->: "+typeof(buff));
                    console.log("enddd------->"+ buff);


                    const path = require('path');
                    const fs = require('fs');
                    // var data = "This is a file containing a collection of books.";
                    // write the file
                    // let baseDir = path.join(__dirname, '/../app/images/');
                    var baseDir = path.join(__dirname, 'images/');
                    console.log(baseDir)
                    fs.open(`${baseDir}car8.jpg`, 'wx', (err, desc) => {
                    if(!err && desc) {
                        fs.writeFile(desc, buff, (err) => {
                            if (err) throw err;               
                            console.log('Results Received');
                        })
                      }
                    })
                  })
                .catch(function (error) {
                  console.log(error);
                });
            
          }
          

          var feedback_data = []
          if (req.body.entry[0].changes[0].value.messages[0].type == "interactive")
            {
              
                var wh_id = req.body.entry[0].changes[0].value.messages[0].id
                  console.log("wh_id_read---->: "+wh_id);

                  // var axios = require('axios');
                  var data = JSON.stringify({
                    "messaging_product": "whatsapp",
                    "status": "read",
                    "message_id": wh_id
                    // "message_id": "wamid.HBgMOTE4NzU0MTA4MjY5FQIAEhggRDNCQjA1OUZCRThEMUFGNjhCQzlERjZBRjNBODM4QkQA"
                  });

                  var config = {
                    method: 'post',
                    url: 'https://graph.facebook.com/v15.0/100411159563677/messages',
                    headers: { 
                      'Content-Type': 'application/json', 
                      'Authorization': 'Bearer EAATQpG7HUWUBALG4ZCqcKutVqY6ZCSePThwNijZBnRafaQTzp7Se7wgDZCbkhgKPlqPn1Aei2rZCHrFHfFontlkcPDLKn18rELdAaNeZBFynUEu4yWjBQT9bX6rwSYyJIA73ZCMZAZAIF5NmtxeT1bKETsvwP5kW9u2ZBgJM20QLl8UvV9MZCHROqZBFnvWvvOTVmb5Bxa1g2t9zmAZDZD'
                    },
                    data : data
                  };

                  axios(config)
                  .then(function (response) {
                    console.log(JSON.stringify(response.data));
                  })
                  .catch(function (error) {
                    console.log(error);
                  });

              var btn_replay_msg = req.body.entry[0].changes[0].value.messages[0].interactive.button_reply.title
              console.log('btn_replay_msg-----> : '+btn_replay_msg)
              if (btn_replay_msg == "Individual report" || btn_replay_msg == "Group report")
                  {
                    var data = JSON.stringify({
                      "messaging_product": "whatsapp",
                      "recipient_type": "individual",
                      "to": "916383963540",
                      "type": "text",
                      "text": {
                        "preview_url": false,
                        "body": "Please enter the your OTP"
                      }
                    });
                    var config = {
                      method: 'post',
                      url: 'https://graph.facebook.com/v15.0/100411159563677/messages',
                      headers: { 
                        'Content-Type': 'application/json', 
                        'Authorization': 'Bearer EAATQpG7HUWUBALG4ZCqcKutVqY6ZCSePThwNijZBnRafaQTzp7Se7wgDZCbkhgKPlqPn1Aei2rZCHrFHfFontlkcPDLKn18rELdAaNeZBFynUEu4yWjBQT9bX6rwSYyJIA73ZCMZAZAIF5NmtxeT1bKETsvwP5kW9u2ZBgJM20QLl8UvV9MZCHROqZBFnvWvvOTVmb5Bxa1g2t9zmAZDZD'
                      },
                      data : data
                    };
                    axios(config)
                    .then(function (response) {
                      console.log(JSON.stringify(response.data));
                    })
                    .catch(function (error) {
                      console.log(error);
                    });
                  }
               // greet_flag = true;
                // greet_flag = false;
              if (btn_replay_msg == "Newsletter")
                {
                  // var axios = require('axios');
                  var data = JSON.stringify({
                    "messaging_product": "whatsapp",
                    "recipient_type": "individual",
                    "to": "916383963540",
                    "type": "interactive",
                    "interactive": {
                      "type": "button",
                      "body": {
                        "text": "Kindly enter the time period."
                      },
                      "action": {
                        "buttons": [
                          {
                            "type": "reply",
                            "reply": {
                              "id": "<UNIQUE_BUTTON_ID_1>",
                              "title": "This month"
                            }
                          },
                          {
                            "type": "reply",
                            "reply": {
                              "id": "<UNIQUE_BUTTON_ID_2>",
                              "title": "Last month"
                            }
                          }
                        ]
                      }
                    }
                  });
                  var config = {
                    method: 'post',
                    url: 'https://graph.facebook.com/v15.0/100411159563677/messages',
                    headers: { 
                      'Content-Type': 'application/json', 
                      'Authorization': 'Bearer EAATQpG7HUWUBALG4ZCqcKutVqY6ZCSePThwNijZBnRafaQTzp7Se7wgDZCbkhgKPlqPn1Aei2rZCHrFHfFontlkcPDLKn18rELdAaNeZBFynUEu4yWjBQT9bX6rwSYyJIA73ZCMZAZAIF5NmtxeT1bKETsvwP5kW9u2ZBgJM20QLl8UvV9MZCHROqZBFnvWvvOTVmb5Bxa1g2t9zmAZDZD'
                    },
                    data : data
                  };
                  axios(config)
                  .then(function (response) {
                    console.log(JSON.stringify(response.data));
                  })
                  .catch(function (error) {
                    console.log(error);
                  });
                }
              // greet_flag = true;
                // greet_flag = false;
               if (btn_replay_msg == "Other Queries")
                {
                 setTimeout(other_btn1, 1000);
                  function other_btn1()
                  {
                      var data = JSON.stringify({
                      "messaging_product": "whatsapp",
                      "recipient_type": "individual",
                      "to": "916383963540",
                      "type": "interactive",
                      "interactive": {
                        "type": "button",
                        "body": {
                          "text": "Display options."
                        },
                        "action": {
                          "buttons": [
                            {
                              "type": "reply",
                              "reply": {
                                "id": "<UNIQUE_BUTTON_ID_1>",
                                "title": "Account Statement"
                              }
                            },
                            {
                              "type": "reply",
                              "reply": {
                                "id": "<UNIQUE_BUTTON_ID_2>",
                                "title": "Client Statement"
                              }
                            },
                            {
                              "type": "reply",
                              "reply": {
                                "id": "<UNIQUE_BUTTON_ID_3>",
                                "title": "Trans Statement"
                              }
                            }
                          ]
                        }
                      }
                    });
                    var config = {
                      method: 'post',
                      url: 'https://graph.facebook.com/v15.0/100411159563677/messages',
                      headers: { 
                        'Content-Type': 'application/json', 
                        'Authorization': 'Bearer EAATQpG7HUWUBALG4ZCqcKutVqY6ZCSePThwNijZBnRafaQTzp7Se7wgDZCbkhgKPlqPn1Aei2rZCHrFHfFontlkcPDLKn18rELdAaNeZBFynUEu4yWjBQT9bX6rwSYyJIA73ZCMZAZAIF5NmtxeT1bKETsvwP5kW9u2ZBgJM20QLl8UvV9MZCHROqZBFnvWvvOTVmb5Bxa1g2t9zmAZDZD'
                      },
                      data : data
                    };
                    axios(config)
                    .then(function (response) {
                      console.log(JSON.stringify(response.data));
                    })
                    .catch(function (error) {
                      console.log(error);
                    });
                   setTimeout(other_btn2, 1000);
                  }
                  function other_btn2()
                  {
                    var data = JSON.stringify({
                      "messaging_product": "whatsapp",
                      "recipient_type": "individual",
                      "to": "916383963540",
                      "type": "interactive",
                      "interactive": {
                        "type": "button",
                        "body": {
                          "text": "For more options :"
                        },
                        "action": {
                          "buttons": [
                            {
                              "type": "reply",
                              "reply": {
                                "id": "<UNIQUE_BUTTON_ID_1>",
                                "title": "Capital Gain"
                              }
                            },
                            {
                              "type": "reply",
                              "reply": {
                                "id": "<UNIQUE_BUTTON_ID_2>",
                                "title": "Others"
                              }
                            }
                          ]
                        }
                      }
                    });
                    var config = {
                      method: 'post',
                      url: 'https://graph.facebook.com/v15.0/100411159563677/messages',
                      headers: { 
                        'Content-Type': 'application/json', 
                        'Authorization': 'Bearer EAATQpG7HUWUBALG4ZCqcKutVqY6ZCSePThwNijZBnRafaQTzp7Se7wgDZCbkhgKPlqPn1Aei2rZCHrFHfFontlkcPDLKn18rELdAaNeZBFynUEu4yWjBQT9bX6rwSYyJIA73ZCMZAZAIF5NmtxeT1bKETsvwP5kW9u2ZBgJM20QLl8UvV9MZCHROqZBFnvWvvOTVmb5Bxa1g2t9zmAZDZD'
                      },
                      data : data
                    };
                    axios(config)
                    .then(function (response) {
                      console.log(JSON.stringify(response.data));
                    })
                    .catch(function (error) {
                      console.log(error);
                    });
                  }
                }
              
              
              if (btn_replay_msg == "Account Statement" || btn_replay_msg == "Client Statement" || btn_replay_msg == "Trans Statement" || btn_replay_msg == "Capital Gain")
                {
                  
                  var data = JSON.stringify({
                        "messaging_product": "whatsapp",
                        "recipient_type": "individual",
                        "to": "916383963540",
                        "type": "text",
                        "text": {
                          "preview_url": false,
                          // "body": "Please enter your PAN number."
                          "body": "Please elaborate the issue your facing."
                          
                        }
                      });
                      var config = {
                        method: 'post',
                        url: 'https://graph.facebook.com/v15.0/100411159563677/messages',
                        headers: { 
                          'Content-Type': 'application/json', 
                          'Authorization': 'Bearer EAATQpG7HUWUBALG4ZCqcKutVqY6ZCSePThwNijZBnRafaQTzp7Se7wgDZCbkhgKPlqPn1Aei2rZCHrFHfFontlkcPDLKn18rELdAaNeZBFynUEu4yWjBQT9bX6rwSYyJIA73ZCMZAZAIF5NmtxeT1bKETsvwP5kW9u2ZBgJM20QLl8UvV9MZCHROqZBFnvWvvOTVmb5Bxa1g2t9zmAZDZD'
                        },
                        data : data
                      };
                      axios(config)
                      .then(function (response) {
                        console.log(JSON.stringify(response.data));
                      })
                      .catch(function (error) {
                        console.log(error);
                      });
                }
              if(btn_replay_msg == "Others")
              {
                var feedback = JSON.stringify({
                        "messaging_product": "whatsapp",
                        "recipient_type": "individual",
                        "to": "916383963540",
                        "type": "text",
                        "text": {
                          "preview_url": false,
                          "body": "What are the issue your facing."
                        }
                      });
                      var config = {
                        method: 'post',
                        url: 'https://graph.facebook.com/v15.0/100411159563677/messages',
                        headers: { 
                          'Content-Type': 'application/json', 
                          'Authorization': 'Bearer EAATQpG7HUWUBALG4ZCqcKutVqY6ZCSePThwNijZBnRafaQTzp7Se7wgDZCbkhgKPlqPn1Aei2rZCHrFHfFontlkcPDLKn18rELdAaNeZBFynUEu4yWjBQT9bX6rwSYyJIA73ZCMZAZAIF5NmtxeT1bKETsvwP5kW9u2ZBgJM20QLl8UvV9MZCHROqZBFnvWvvOTVmb5Bxa1g2t9zmAZDZD'
                        },
                        data : feedback
                      };
                
                      feedback_data.push(feedback)
                      console.log("feedback1-->: "+feedback)
                      console.log("feedback2-->: "+feedback_data)
//                       if(feedback.type == 'text')
//                       {
//                         console.log("feedback_msg-->: "+feedback.text.body)
//                       }
                
                      axios(config)
                      .then(function (response) {
                        console.log(JSON.stringify(response.data));
                      })
                      .catch(function (error) {
                        console.log(error);
                      });
              }
              // greet_flag = true;
                // greet_flag = false;
              if (btn_replay_msg == "This month" || btn_replay_msg == "Last month")
                {
                    var data = JSON.stringify({
                    "messaging_product": "whatsapp",
                    "recipient_type": "individual",
                    "to": "916383963540",
                    "type": "document",
                    "document": {
                      "link": "https://www.africau.edu/images/default/sample.pdf",
                      "caption": "Thanks for your request. Here is your document."
                    }
                  });
                  var config = {
                    method: 'post',
                    url: 'https://graph.facebook.com/v15.0/100411159563677/messages',
                    headers: { 
                      'Content-Type': 'application/json', 
                      'Authorization': 'Bearer EAATQpG7HUWUBALG4ZCqcKutVqY6ZCSePThwNijZBnRafaQTzp7Se7wgDZCbkhgKPlqPn1Aei2rZCHrFHfFontlkcPDLKn18rELdAaNeZBFynUEu4yWjBQT9bX6rwSYyJIA73ZCMZAZAIF5NmtxeT1bKETsvwP5kW9u2ZBgJM20QLl8UvV9MZCHROqZBFnvWvvOTVmb5Bxa1g2t9zmAZDZD'
                    },
                    data : data
                  };
                  axios(config)
                  .then(function (response) {
                    console.log(JSON.stringify(response.data));
                  })
                  .catch(function (error) {
                    console.log(error);
                  });
                  
                  
                  // var data = JSON.stringify({
                  //       "messaging_product": "whatsapp",
                  //       "recipient_type": "individual",
                  //       "to": "916383963540",
                  //       "type": "text",
                  //       "text": {
                  //         "preview_url": false,
                  //         "body": "Thanks for your request. A ticket has been created and assigned to your RM / CSO. An RM / CSO will contact you at the earliest to respond to your query."
                  //       }
                  //     });
                  //     var config = {
                  //       method: 'post',
                  //       url: 'https://graph.facebook.com/v15.0/100411159563677/messages',
                  //       headers: { 
                  //         'Content-Type': 'application/json', 
                  //         'Authorization': 'Bearer EAATQpG7HUWUBALG4ZCqcKutVqY6ZCSePThwNijZBnRafaQTzp7Se7wgDZCbkhgKPlqPn1Aei2rZCHrFHfFontlkcPDLKn18rELdAaNeZBFynUEu4yWjBQT9bX6rwSYyJIA73ZCMZAZAIF5NmtxeT1bKETsvwP5kW9u2ZBgJM20QLl8UvV9MZCHROqZBFnvWvvOTVmb5Bxa1g2t9zmAZDZD'
                  //       },
                  //       data : data
                  //     };
                  //     axios(config)
                  //     .then(function (response) {
                  //       console.log(JSON.stringify(response.data));
                  //     })
                  //     .catch(function (error) {
                  //       console.log(error);
                  //     });
                  
                  setTimeout(return_temp3, 5000);
                   function return_temp3(){
                      var data = JSON.stringify({
                        "messaging_product": "whatsapp",
                        "recipient_type": "individual",
                        "to": "916383963540",
                        "type": "template",
                        "template": {
                          "name": "testing_template",
                          "language": {
                            "code": "en_US"
                          },
                          "components": [
                            {
                              "type": "button",
                              "sub_type": "quick_reply",
                              "index": "0",
                              "parameters": [
                                {
                                  "type": "payload",
                                  "payload": "aGlzIHRoaXMgaXMgY29v"
                                }
                              ]
                            },
                            {
                              "type": "button",
                              "sub_type": "quick_reply",
                              "index": "1",
                              "parameters": [
                                {
                                  "type": "payload",
                                  "payload": "9rwnB8RbYmPF5t2Mn09x4h"
                                }
                              ]
                            },
                            {
                              "type": "button",
                              "sub_type": "quick_reply",
                              "index": "2",
                              "parameters": [
                                {
                                  "type": "payload",
                                  "payload": "aGlzIHRoaXMgaXMgY29v"
                                }
                              ]
                            }
                          ]
                        }
                      });
                    var config = {
                      method: 'post',
                      url: 'https://graph.facebook.com/v15.0/100411159563677/messages',
                      headers: { 
                        'Content-Type': 'application/json', 
                        'Authorization': 'Bearer EAATQpG7HUWUBALG4ZCqcKutVqY6ZCSePThwNijZBnRafaQTzp7Se7wgDZCbkhgKPlqPn1Aei2rZCHrFHfFontlkcPDLKn18rELdAaNeZBFynUEu4yWjBQT9bX6rwSYyJIA73ZCMZAZAIF5NmtxeT1bKETsvwP5kW9u2ZBgJM20QLl8UvV9MZCHROqZBFnvWvvOTVmb5Bxa1g2t9zmAZDZD'
                      },
                      data : data
                    };
                    console.log("api_button_data-->"+data);
                    axios(config)
                    .then(function (response) {
                      console.log(JSON.stringify(response.data));
                    })
                    .catch(function (error) {
                      console.log(error);
                    });
                     setTimeout(return_temp4, 1000);
                  }
                  function return_temp4(){
                    var data = JSON.stringify({
                      "messaging_product": "whatsapp",
                      "recipient_type": "individual",
                      "to": "916383963540",
                      "type": "interactive",
                      "interactive": {
                        "type": "button",
                        "body": {
                          "text": "For more options :"
                        },
                        "action": {
                          "buttons": [
                            {
                              "type": "reply",
                              "reply": {
                                "id": "<UNIQUE_BUTTON_ID_1>",
                                "title": "Newsletter"
                              }
                            },
                            {
                              "type": "reply",
                              "reply": {
                                "id": "<UNIQUE_BUTTON_ID_2>",
                                "title": "Other Queries"
                              }
                            }
                          ]
                        }
                      }
                    });
                    var config = {
                      method: 'post',
                      url: 'https://graph.facebook.com/v15.0/100411159563677/messages',
                      headers: { 
                        'Content-Type': 'application/json', 
                        'Authorization': 'Bearer EAATQpG7HUWUBALG4ZCqcKutVqY6ZCSePThwNijZBnRafaQTzp7Se7wgDZCbkhgKPlqPn1Aei2rZCHrFHfFontlkcPDLKn18rELdAaNeZBFynUEu4yWjBQT9bX6rwSYyJIA73ZCMZAZAIF5NmtxeT1bKETsvwP5kW9u2ZBgJM20QLl8UvV9MZCHROqZBFnvWvvOTVmb5Bxa1g2t9zmAZDZD'
                      },
                      data : data
                    };
                    axios(config)
                    .then(function (response) {
                      console.log(JSON.stringify(response.data));
                    })
                    .catch(function (error) {
                      console.log(error);
                    });
                  }
                }
              // greet_flag = true;
                // greet_flag = false;
            }
            
            // Button Message Template
            if (req.body.entry[0].changes[0].value.messages[0].type == "button")              
              {
                
                var wh_id = req.body.entry[0].changes[0].value.messages[0].id
                console.log("wh_id_read---->: "+wh_id);

                // var axios = require('axios');
                var data = JSON.stringify({
                  "messaging_product": "whatsapp",
                  "status": "read",
                  "message_id": wh_id
                  // "message_id": "wamid.HBgMOTE4NzU0MTA4MjY5FQIAEhggRDNCQjA1OUZCRThEMUFGNjhCQzlERjZBRjNBODM4QkQA"
                });

                var config = {
                  method: 'post',
                  url: 'https://graph.facebook.com/v15.0/100411159563677/messages',
                  headers: { 
                    'Content-Type': 'application/json', 
                    'Authorization': 'Bearer EAATQpG7HUWUBALG4ZCqcKutVqY6ZCSePThwNijZBnRafaQTzp7Se7wgDZCbkhgKPlqPn1Aei2rZCHrFHfFontlkcPDLKn18rELdAaNeZBFynUEu4yWjBQT9bX6rwSYyJIA73ZCMZAZAIF5NmtxeT1bKETsvwP5kW9u2ZBgJM20QLl8UvV9MZCHROqZBFnvWvvOTVmb5Bxa1g2t9zmAZDZD'
                  },
                  data : data
                };

                axios(config)
                .then(function (response) {
                  console.log(JSON.stringify(response.data));
                })
                .catch(function (error) {
                  console.log(error);
                });

                var user_btn_msg = req.body.entry[0].changes[0].value.messages[0].button.text; // extract the phone number from the webhook payload
                console.log("user_btn_msg: "+user_btn_msg);
                if (user_btn_msg == "Account Statement")
                  {
                    //next api
                    // var axios = require('axios');
                    var data = JSON.stringify({
                      "messaging_product": "whatsapp",
                      "recipient_type": "individual",
                      "to": "916383963540",
                      "type": "template",
                      "template": {
                        "name": "account_time_period",
                        "language": {
                          "code": "en_US"
                        },
                        "components": [
                          {
                            "type": "button",
                            "sub_type": "quick_reply",
                            "index": "0",
                            "parameters": [
                              {
                                "type": "payload",
                                "payload": "aGlzIHRoaXMgaXMgY29v"
                              }
                            ]
                          },
                          {
                            "type": "button",
                            "sub_type": "quick_reply",
                            "index": "1",
                            "parameters": [
                              {
                                "type": "payload",
                                "payload": "9rwnB8RbYmPF5t2Mn09x4h"
                              }
                            ]
                          },
                          {
                            "type": "button",
                            "sub_type": "quick_reply",
                            "index": "2",
                            "parameters": [
                              {
                                "type": "payload",
                                "payload": "aGlzIHRoaXMgaXMgY29v"
                              }
                            ]
                          }
                        ]
                      }
                    });
                    var config = {
                      method: 'post',
                      url: 'https://graph.facebook.com/v15.0/100411159563677/messages',
                      headers: { 
                        'Content-Type': 'application/json', 
                        'Authorization': 'Bearer EAATQpG7HUWUBALG4ZCqcKutVqY6ZCSePThwNijZBnRafaQTzp7Se7wgDZCbkhgKPlqPn1Aei2rZCHrFHfFontlkcPDLKn18rELdAaNeZBFynUEu4yWjBQT9bX6rwSYyJIA73ZCMZAZAIF5NmtxeT1bKETsvwP5kW9u2ZBgJM20QLl8UvV9MZCHROqZBFnvWvvOTVmb5Bxa1g2t9zmAZDZD'
                      },
                      data : data
                    };
                    axios(config)
                    .then(function (response) {
                      console.log(JSON.stringify(response.data));
                    })
                    .catch(function (error) {
                      console.log(error);
                    });
                  }
                   if (user_btn_msg == "Last month" || user_btn_msg == "Current month" || user_btn_msg == "Month before")
                    {
                      // var axios = require('axios');
                      var data = JSON.stringify({
                        "messaging_product": "whatsapp",
                        "recipient_type": "individual",
                        "to": "916383963540",
                        "type": "text",
                        "text": {
                          "preview_url": false,
                          "body": "Please enter your PAN number. "
                        }
                      });
                      var config = {
                        method: 'post',
                        url: 'https://graph.facebook.com/v15.0/100411159563677/messages',
                        headers: { 
                          'Content-Type': 'application/json', 
                          'Authorization': 'Bearer EAATQpG7HUWUBALG4ZCqcKutVqY6ZCSePThwNijZBnRafaQTzp7Se7wgDZCbkhgKPlqPn1Aei2rZCHrFHfFontlkcPDLKn18rELdAaNeZBFynUEu4yWjBQT9bX6rwSYyJIA73ZCMZAZAIF5NmtxeT1bKETsvwP5kW9u2ZBgJM20QLl8UvV9MZCHROqZBFnvWvvOTVmb5Bxa1g2t9zmAZDZD'
                        },
                        data : data
                      };
                      axios(config)
                      .then(function (response) {
                        console.log(JSON.stringify(response.data));
                      })
                      .catch(function (error) {
                        console.log(error);
                      });
                       // greet_flag = true;
                      // greet_flag = false;
                    }
               // greet_flag = true;
                // greet_flag = false;
                if (user_btn_msg == "Transaction Statement")
                  {
                    // var axios = require('axios');
                    var data = JSON.stringify({
                      "messaging_product": "whatsapp",
                      "recipient_type": "individual",
                      "to": "916383963540",
                      "type": "template",
                      "template": {
                        "name": "transaction_time_period",
                        "language": {
                          "code": "en_US"
                        },
                        "components": [
                          {
                            "type": "button",
                            "sub_type": "quick_reply",
                            "index": "0",
                            "parameters": [
                              {
                                "type": "payload",
                                "payload": "aGlzIHRoaXMgaXMgY29v"
                              }
                            ]
                          },
                          {
                            "type": "button",
                            "sub_type": "quick_reply",
                            "index": "1",
                            "parameters": [
                              {
                                "type": "payload",
                                "payload": "9rwnB8RbYmPF5t2Mn09x4h"
                              }
                            ]
                          },
                          {
                            "type": "button",
                            "sub_type": "quick_reply",
                            "index": "2",
                            "parameters": [
                              {
                                "type": "payload",
                                "payload": "9rwnB8RbYmPF5t2Mn09x4h"
                              }
                            ]
                          }
                        ]
                      }
                    });
                    var config = {
                      method: 'post',
                      url: 'https://graph.facebook.com/v15.0/100411159563677/messages',
                      headers: { 
                        'Content-Type': 'application/json', 
                        'Authorization': 'Bearer EAATQpG7HUWUBALG4ZCqcKutVqY6ZCSePThwNijZBnRafaQTzp7Se7wgDZCbkhgKPlqPn1Aei2rZCHrFHfFontlkcPDLKn18rELdAaNeZBFynUEu4yWjBQT9bX6rwSYyJIA73ZCMZAZAIF5NmtxeT1bKETsvwP5kW9u2ZBgJM20QLl8UvV9MZCHROqZBFnvWvvOTVmb5Bxa1g2t9zmAZDZD'
                      },
                      data : data
                    };
                    axios(config)
                    .then(function (response) {
                      console.log(JSON.stringify(response.data));
                    })
                    .catch(function (error) {
                      console.log(error);
                    });
                  }
                if (user_btn_msg == "Last 2 days" || user_btn_msg == "Last 7 days" || user_btn_msg == "Last 30 days")
                  {
                    var data = JSON.stringify({
                      "messaging_product": "whatsapp",
                      "recipient_type": "individual",
                      "to": "916383963540",
                      "type": "text",
                      "text": {
                        "preview_url": false,
                        "body": "Please enter your PAN number. "
                      }
                    });
                    var config = {
                      method: 'post',
                      url: 'https://graph.facebook.com/v15.0/100411159563677/messages',
                      headers: { 
                        'Content-Type': 'application/json', 
                        'Authorization': 'Bearer EAATQpG7HUWUBALG4ZCqcKutVqY6ZCSePThwNijZBnRafaQTzp7Se7wgDZCbkhgKPlqPn1Aei2rZCHrFHfFontlkcPDLKn18rELdAaNeZBFynUEu4yWjBQT9bX6rwSYyJIA73ZCMZAZAIF5NmtxeT1bKETsvwP5kW9u2ZBgJM20QLl8UvV9MZCHROqZBFnvWvvOTVmb5Bxa1g2t9zmAZDZD'
                      },
                      data : data
                    };
                    axios(config)
                    .then(function (response) {
                      console.log(JSON.stringify(response.data));
                    })
                    .catch(function (error) {
                      console.log(error);
                    });
                  }
                if (user_btn_msg == "Capital Gain Statement")
                  {
                    // var axios = require('axios');
                    var data = JSON.stringify({
                      "messaging_product": "whatsapp",
                      "recipient_type": "individual",
                      "to": "916383963540",
                      "type": "template",
                      "template": {
                        "name": "capital_button",
                        "language": {
                          "code": "en_US"
                        },
                        "components": [
                          {
                            "type": "button",
                            "sub_type": "quick_reply",
                            "index": "0",
                            "parameters": [
                              {
                                "type": "payload",
                                "payload": "aGlzIHRoaXMgaXMgY29v"
                              }
                            ]
                          },
                          {
                            "type": "button",
                            "sub_type": "quick_reply",
                            "index": "1",
                            "parameters": [
                              {
                                "type": "payload",
                                "payload": "9rwnB8RbYmPF5t2Mn09x4h"
                              }
                            ]
                          }
                        ]
                      }
                    });
                    var config = {
                      method: 'post',
                      url: 'https://graph.facebook.com/v15.0/100411159563677/messages',
                      headers: { 
                        'Content-Type': 'application/json', 
                        'Authorization': 'Bearer EAATQpG7HUWUBALG4ZCqcKutVqY6ZCSePThwNijZBnRafaQTzp7Se7wgDZCbkhgKPlqPn1Aei2rZCHrFHfFontlkcPDLKn18rELdAaNeZBFynUEu4yWjBQT9bX6rwSYyJIA73ZCMZAZAIF5NmtxeT1bKETsvwP5kW9u2ZBgJM20QLl8UvV9MZCHROqZBFnvWvvOTVmb5Bxa1g2t9zmAZDZD'
                      },
                      data : data
                    };
                    axios(config)
                    .then(function (response) {
                      console.log(JSON.stringify(response.data));
                    })
                    .catch(function (error) {
                      console.log(error);
                    });
                  }
                if (user_btn_msg == "Current Financial Year" || user_btn_msg == "Last Financial Year")
                  {
                    var data = JSON.stringify({
                      "messaging_product": "whatsapp",
                      "recipient_type": "individual",
                      "to": "916383963540",
                      "type": "text",
                      "text": {
                        "preview_url": false,
                        "body": "Please enter your PAN number. "
                      }
                    });
                    var config = {
                      method: 'post',
                      url: 'https://graph.facebook.com/v15.0/100411159563677/messages',
                      headers: { 
                        'Content-Type': 'application/json', 
                        'Authorization': 'Bearer EAATQpG7HUWUBALG4ZCqcKutVqY6ZCSePThwNijZBnRafaQTzp7Se7wgDZCbkhgKPlqPn1Aei2rZCHrFHfFontlkcPDLKn18rELdAaNeZBFynUEu4yWjBQT9bX6rwSYyJIA73ZCMZAZAIF5NmtxeT1bKETsvwP5kW9u2ZBgJM20QLl8UvV9MZCHROqZBFnvWvvOTVmb5Bxa1g2t9zmAZDZD'
                      },
                      data : data
                    };
                    axios(config)
                    .then(function (response) {
                      console.log(JSON.stringify(response.data));
                    })
                    .catch(function (error) {
                      console.log(error);
                    });
                    
                  }
              }
      
//             if (feedback_data)
//             {
//                 console.log('feedback_data2---->:'+feedback_data)
//                 console.log('feedback_data3---->:'+feedback_data.text)
              
//               // if (feedback_data.text.body == 'Please enter your feedback.')
//               // {
//               //   console.log('feedback_data2---->:'+feedback_data)
//               //   // console.log('feedback_data2---->:'+feedback_data.text.body) 
//               // }
               
//             }
            
            // Text Templete
            if (req.body.entry[0].changes[0].value.messages[0].type == 'text')
            {
              
              
                var user_msg = req.body.entry[0].changes[0].value.messages[0].text.body; // extract the phone number from the webhook payload
                // var user_msg2 = req.body.entry[0].changes[0].value.messages[0].text.body; // extract the phone number from the webhook payload
                   
                var wh_id = req.body.entry[0].changes[0].value.messages[0].id
                console.log("wh_id_read---->: "+wh_id);

                // var axios = require('axios');
                var data = JSON.stringify({
                  "messaging_product": "whatsapp",
                  "status": "read",
                  "message_id": wh_id
                  // "message_id": "wamid.HBgMOTE4NzU0MTA4MjY5FQIAEhggRDNCQjA1OUZCRThEMUFGNjhCQzlERjZBRjNBODM4QkQA"
                });

                var config = {
                  method: 'post',
                  url: 'https://graph.facebook.com/v15.0/100411159563677/messages',
                  headers: { 
                    'Content-Type': 'application/json', 
                    'Authorization': 'Bearer EAATQpG7HUWUBALG4ZCqcKutVqY6ZCSePThwNijZBnRafaQTzp7Se7wgDZCbkhgKPlqPn1Aei2rZCHrFHfFontlkcPDLKn18rELdAaNeZBFynUEu4yWjBQT9bX6rwSYyJIA73ZCMZAZAIF5NmtxeT1bKETsvwP5kW9u2ZBgJM20QLl8UvV9MZCHROqZBFnvWvvOTVmb5Bxa1g2t9zmAZDZD'
                  },
                  data : data
                };

                axios(config)
                .then(function (response) {
                  console.log(JSON.stringify(response.data));
                })
                .catch(function (error) {
                  console.log(error);
                });

                  var txt=user_msg
                  txt = txt.toUpperCase();
                  var regex = /[a-zA-Z]{3}[PCHFATBLJG]{1}[a-zA-Z]{1}[0-9]{4}[a-zA-Z]{1}$/;
              
                  pan_func();
                  
                  var number2 = (user_msg).length
                  console.log("number2: "+number2 + " TypeOf-->: "+ typeof(number2))
                  console.log(typeof(user_msg))
                 
              
                   if(user_msg != 'hi' && user_msg != 'Hi' && number2 != 6 && regex.test(txt) == false)
                   // if(!pan_func())
                    {
                      console.log("user_msg_feedback-->: "+user_msg)
                      var data = JSON.stringify({
                            "messaging_product": "whatsapp",
                            "recipient_type": "individual",
                            "to": "916383963540",
                            "type": "text",
                            "text": {
                              "preview_url": false,
                              "body": "Thanks for your request. A ticket has been created and assigned to your RM / CSO. An RM / CSO will contact you at the earliest to respond to your query."
                        }
                      });
                      var config = {
                        method: 'post',
                        url: 'https://graph.facebook.com/v15.0/100411159563677/messages',
                        headers: { 
                          'Content-Type': 'application/json', 
                          'Authorization': 'Bearer EAATQpG7HUWUBALG4ZCqcKutVqY6ZCSePThwNijZBnRafaQTzp7Se7wgDZCbkhgKPlqPn1Aei2rZCHrFHfFontlkcPDLKn18rELdAaNeZBFynUEu4yWjBQT9bX6rwSYyJIA73ZCMZAZAIF5NmtxeT1bKETsvwP5kW9u2ZBgJM20QLl8UvV9MZCHROqZBFnvWvvOTVmb5Bxa1g2t9zmAZDZD'
                        },
                        data : data
                      };
                      console.log("api_msg_data-->"+data);
                      axios(config)
                      .then(function (response) {
                        console.log(JSON.stringify(response.data));
                      })
                      .catch(function (error) {
                        console.log(error);
                      });
                      
                    setTimeout(api_call, 5000);
                      
                    function api_call(){
                        // message template
                        console.log("greet_flag--> "+greet_flag)
                        if (greet_flag == true) {
                          // Button Template
                                button_temp();
                               function button_temp(){
                                 
                                  var data = JSON.stringify({
                                    "messaging_product": "whatsapp",
                                    "recipient_type": "individual",
                                    "to": "916383963540",
                                    "type": "template",
                                    "template": {
                                      "name": "testing_template",
                                      "language": {
                                        "code": "en_US"
                                      },
                                      "components": [
                                        {
                                          "type": "button",
                                          "sub_type": "quick_reply",
                                          "index": "0",
                                          "parameters": [
                                            {
                                              "type": "payload",
                                              "payload": "aGlzIHRoaXMgaXMgY29v"
                                            }
                                          ]
                                        },
                                        {
                                          "type": "button",
                                          "sub_type": "quick_reply",
                                          "index": "1",
                                          "parameters": [
                                            {
                                              "type": "payload",
                                              "payload": "9rwnB8RbYmPF5t2Mn09x4h"
                                            }
                                          ]
                                        },
                                        {
                                          "type": "button",
                                          "sub_type": "quick_reply",
                                          "index": "2",
                                          "parameters": [
                                            {
                                              "type": "payload",
                                              "payload": "aGlzIHRoaXMgaXMgY29v"
                                            }
                                          ]
                                        }
                                      ]
                                    }
                                  });
                                var config = {
                                  method: 'post',
                                  url: 'https://graph.facebook.com/v15.0/100411159563677/messages',
                                  headers: { 
                                    'Content-Type': 'application/json', 
                                    'Authorization': 'Bearer EAATQpG7HUWUBALG4ZCqcKutVqY6ZCSePThwNijZBnRafaQTzp7Se7wgDZCbkhgKPlqPn1Aei2rZCHrFHfFontlkcPDLKn18rELdAaNeZBFynUEu4yWjBQT9bX6rwSYyJIA73ZCMZAZAIF5NmtxeT1bKETsvwP5kW9u2ZBgJM20QLl8UvV9MZCHROqZBFnvWvvOTVmb5Bxa1g2t9zmAZDZD'
                                  },
                                  data : data
                                };
                                console.log("api_button_data-->"+data);
                                axios(config)
                                .then(function (response) {
                                  console.log(JSON.stringify(response.data));
                                })
                                .catch(function (error) {
                                  console.log(error);
                                });
                                 setTimeout(other_buttons, 1000);
                              }
                              function other_buttons(){
                                var data = JSON.stringify({
                                  "messaging_product": "whatsapp",
                                  "recipient_type": "individual",
                                  "to": "916383963540",
                                  "type": "interactive",
                                  "interactive": {
                                    "type": "button",
                                    "body": {
                                      "text": "For more options :"
                                    },
                                    "action": {
                                      "buttons": [
                                        {
                                          "type": "reply",
                                          "reply": {
                                            "id": "<UNIQUE_BUTTON_ID_1>",
                                            "title": "Newsletter"
                                          }
                                        },
                                        {
                                          "type": "reply",
                                          "reply": {
                                            "id": "<UNIQUE_BUTTON_ID_2>",
                                            "title": "Other Queries"
                                          }
                                        }
                                      ]
                                    }
                                  }
                                });
                                var config = {
                                  method: 'post',
                                  url: 'https://graph.facebook.com/v15.0/100411159563677/messages',
                                  headers: { 
                                    'Content-Type': 'application/json', 
                                    'Authorization': 'Bearer EAATQpG7HUWUBALG4ZCqcKutVqY6ZCSePThwNijZBnRafaQTzp7Se7wgDZCbkhgKPlqPn1Aei2rZCHrFHfFontlkcPDLKn18rELdAaNeZBFynUEu4yWjBQT9bX6rwSYyJIA73ZCMZAZAIF5NmtxeT1bKETsvwP5kW9u2ZBgJM20QLl8UvV9MZCHROqZBFnvWvvOTVmb5Bxa1g2t9zmAZDZD'
                                  },
                                  data : data
                                };
                                axios(config)
                                .then(function (response) {
                                  console.log(JSON.stringify(response.data));
                                })
                                .catch(function (error) {
                                  console.log(error);
                                });
                              }
                          // greet_flag = true;
                          // greet_flag = false;
                          }
                      }
                    }
                  console.log("user_msg: "+user_msg);

                  if (user_msg == "Hi" || user_msg == "hi" || user_msg == "hello" || user_msg == "Hello")
                  {

                    api_call();
                    function api_call(){
                        // message template
                        console.log("greet_flag--> "+greet_flag)
                        if (greet_flag == true) {
                          // Button Template
                          // var axios = require('axios');
                            // var axios = require('axios');

                            var data = JSON.stringify({
                                    "messaging_product": "whatsapp",
                                    "recipient_type": "individual",
                                    "to": "916383963540",
                                    "type": "text",
                                    "text": {
                                      "preview_url": false,
                                      "body": "I am ZIVA, your personal assistant to help you with XG related queries. let me know. "
                                }
                              });
                              var config = {
                                method: 'post',
                                url: 'https://graph.facebook.com/v15.0/100411159563677/messages',
                                headers: { 
                                  'Content-Type': 'application/json', 
                                  'Authorization': 'Bearer EAATQpG7HUWUBALG4ZCqcKutVqY6ZCSePThwNijZBnRafaQTzp7Se7wgDZCbkhgKPlqPn1Aei2rZCHrFHfFontlkcPDLKn18rELdAaNeZBFynUEu4yWjBQT9bX6rwSYyJIA73ZCMZAZAIF5NmtxeT1bKETsvwP5kW9u2ZBgJM20QLl8UvV9MZCHROqZBFnvWvvOTVmb5Bxa1g2t9zmAZDZD'
                                },
                                data : data
                              };
                              console.log("api_msg_data-->"+data);
                              axios(config)
                              .then(function (response) {
                                console.log(JSON.stringify(response.data));
                              })
                              .catch(function (error) {
                                console.log(error);
                              });
                             // button_temp();
                             setTimeout(button_temp, 1000);
                             // button_temp();
                               function button_temp(){
                                  var data = JSON.stringify({
                                    "messaging_product": "whatsapp",
                                    "recipient_type": "individual",
                                    "to": "916383963540",
                                    "type": "template",
                                    "template": {
                                      "name": "testing_template",
                                      "language": {
                                        "code": "en_US"
                                      },
                                      "components": [
                                        {
                                          "type": "button",
                                          "sub_type": "quick_reply",
                                          "index": "0",
                                          "parameters": [
                                            {
                                              "type": "payload",
                                              "payload": "aGlzIHRoaXMgaXMgY29v"
                                            }
                                          ]
                                        },
                                        {
                                          "type": "button",
                                          "sub_type": "quick_reply",
                                          "index": "1",
                                          "parameters": [
                                            {
                                              "type": "payload",
                                              "payload": "9rwnB8RbYmPF5t2Mn09x4h"
                                            }
                                          ]
                                        },
                                        {
                                          "type": "button",
                                          "sub_type": "quick_reply",
                                          "index": "2",
                                          "parameters": [
                                            {
                                              "type": "payload",
                                              "payload": "aGlzIHRoaXMgaXMgY29v"
                                            }
                                          ]
                                        }
                                      ]
                                    }
                                  });
                                var config = {
                                  method: 'post',
                                  url: 'https://graph.facebook.com/v15.0/100411159563677/messages',
                                  headers: { 
                                    'Content-Type': 'application/json', 
                                    'Authorization': 'Bearer EAATQpG7HUWUBALG4ZCqcKutVqY6ZCSePThwNijZBnRafaQTzp7Se7wgDZCbkhgKPlqPn1Aei2rZCHrFHfFontlkcPDLKn18rELdAaNeZBFynUEu4yWjBQT9bX6rwSYyJIA73ZCMZAZAIF5NmtxeT1bKETsvwP5kW9u2ZBgJM20QLl8UvV9MZCHROqZBFnvWvvOTVmb5Bxa1g2t9zmAZDZD'
                                  },
                                  data : data
                                };
                                console.log("api_button_data-->"+data);
                                axios(config)
                                .then(function (response) {
                                  console.log(JSON.stringify(response.data));
                                })
                                .catch(function (error) {
                                  console.log(error);
                                });
                                 setTimeout(other_buttons, 1000);
                              }
                              function other_buttons(){
                                var data = JSON.stringify({
                                  "messaging_product": "whatsapp",
                                  "recipient_type": "individual",
                                  "to": "916383963540",
                                  "type": "interactive",
                                  "interactive": {
                                    "type": "button",
                                    "body": {
                                      "text": "For more options :"
                                    },
                                    "action": {
                                      "buttons": [
                                        {
                                          "type": "reply",
                                          "reply": {
                                            "id": "<UNIQUE_BUTTON_ID_1>",
                                            "title": "Newsletter"
                                          }
                                        },
                                        {
                                          "type": "reply",
                                          "reply": {
                                            "id": "<UNIQUE_BUTTON_ID_2>",
                                            "title": "Other Queries"
                                          }
                                        }
                                      ]
                                    }
                                  }
                                });
                                var config = {
                                  method: 'post',
                                  url: 'https://graph.facebook.com/v15.0/100411159563677/messages',
                                  headers: { 
                                    'Content-Type': 'application/json', 
                                    'Authorization': 'Bearer EAATQpG7HUWUBALG4ZCqcKutVqY6ZCSePThwNijZBnRafaQTzp7Se7wgDZCbkhgKPlqPn1Aei2rZCHrFHfFontlkcPDLKn18rELdAaNeZBFynUEu4yWjBQT9bX6rwSYyJIA73ZCMZAZAIF5NmtxeT1bKETsvwP5kW9u2ZBgJM20QLl8UvV9MZCHROqZBFnvWvvOTVmb5Bxa1g2t9zmAZDZD'
                                  },
                                  data : data
                                };
                                axios(config)
                                .then(function (response) {
                                  console.log(JSON.stringify(response.data));
                                })
                                .catch(function (error) {
                                  console.log(error);
                                });
                              }
                          // greet_flag = true;
                          // greet_flag = false;
                          }
                      }
                  }

                  function pan_func()
                  {
                    
                    if (/[a-zA-Z]{3}[PCHFATBLJG]{1}[a-zA-Z]{1}[0-9]{4}[a-zA-Z]{1}$/)
                    {
                        var txt=user_msg
                        txt = txt.toUpperCase();
                        var regex = /[a-zA-Z]{3}[PCHFATBLJG]{1}[a-zA-Z]{1}[0-9]{4}[a-zA-Z]{1}$/;
                        if(regex.test(txt))
                        {
                            var data = JSON.stringify({
                            "messaging_product": "whatsapp",
                            "recipient_type": "individual",
                            "to": "916383963540",
                            "type": "interactive",
                            "interactive": {
                              "type": "button",
                              "body": {
                                "text": "Do you want to generate family report?"
                              },
                              "action": {
                                "buttons": [
                                  {
                                    "type": "reply",
                                    "reply": {
                                      "id": "<UNIQUE_BUTTON_ID_1>",
                                      "title": "Individual report"
                                    }
                                  },
                                  {
                                    "type": "reply",
                                    "reply": {
                                      "id": "<UNIQUE_BUTTON_ID_2>",
                                      "title": "Group report"
                                    }
                                  }
                                ]
                              }
                            }
                          });
                          var config = {
                            method: 'post',
                            url: 'https://graph.facebook.com/v15.0/100411159563677/messages',
                            headers: { 
                              'Content-Type': 'application/json', 
                              'Authorization': 'Bearer EAATQpG7HUWUBALG4ZCqcKutVqY6ZCSePThwNijZBnRafaQTzp7Se7wgDZCbkhgKPlqPn1Aei2rZCHrFHfFontlkcPDLKn18rELdAaNeZBFynUEu4yWjBQT9bX6rwSYyJIA73ZCMZAZAIF5NmtxeT1bKETsvwP5kW9u2ZBgJM20QLl8UvV9MZCHROqZBFnvWvvOTVmb5Bxa1g2t9zmAZDZD'
                            },
                            data : data
                          };
                          axios(config)
                          .then(function (response) {
                            console.log(JSON.stringify(response.data));
                          })
                          .catch(function (error) {
                            console.log(error);
                          });

                        } 
                        // else{
                        //    console.log("Unknown card2");
                        //     var data = JSON.stringify({
                        //                 "messaging_product": "whatsapp",
                        //                 "recipient_type": "individual",
                        //                 "to": "916383963540",
                        //                 "type": "text",
                        //                 "text": {
                        //                   "preview_url": false,
                        //                   "body": "Invalid PAN number please check..!"
                        //             }
                        //           });
                        //           var config = {
                        //             method: 'post',
                        //             url: 'https://graph.facebook.com/v15.0/100411159563677/messages',
                        //             headers: { 
                        //               'Content-Type': 'application/json', 
                        //               'Authorization': 'Bearer EAATQpG7HUWUBALG4ZCqcKutVqY6ZCSePThwNijZBnRafaQTzp7Se7wgDZCbkhgKPlqPn1Aei2rZCHrFHfFontlkcPDLKn18rELdAaNeZBFynUEu4yWjBQT9bX6rwSYyJIA73ZCMZAZAIF5NmtxeT1bKETsvwP5kW9u2ZBgJM20QLl8UvV9MZCHROqZBFnvWvvOTVmb5Bxa1g2t9zmAZDZD'
                        //             },
                        //             data : data
                        //           };
                        //           console.log("api_msg_data-->"+data);
                        //           axios(config)
                        //           .then(function (response) {
                        //             console.log(JSON.stringify(response.data));
                        //           })
                        //           .catch(function (error) {
                        //             console.log(error);
                        //           });
                        //     }
                    }

                  }
                  // var number1 = 1234567;

                  var number2 = (user_msg).length
                  console.log("number2: "+number2 + " TypeOf-->: "+ typeof(number2))
                  console.log(typeof(user_msg))

                  // if (user_msg == "123456")
                  if (number2 == 6)
                  {
                    // var axios = require('axios');
                    var data = JSON.stringify({
                      "messaging_product": "whatsapp",
                      "recipient_type": "individual",
                      "to": "916383963540",
                      "type": "document",
                      "document": {
                        "link": "https://www.africau.edu/images/default/sample.pdf",
                        "caption": "Thanks for your request. Here is your document."
                      }
                    });
                    var config = {
                      method: 'post',
                      url: 'https://graph.facebook.com/v15.0/100411159563677/messages',
                      headers: { 
                        'Content-Type': 'application/json', 
                        'Authorization': 'Bearer EAATQpG7HUWUBALG4ZCqcKutVqY6ZCSePThwNijZBnRafaQTzp7Se7wgDZCbkhgKPlqPn1Aei2rZCHrFHfFontlkcPDLKn18rELdAaNeZBFynUEu4yWjBQT9bX6rwSYyJIA73ZCMZAZAIF5NmtxeT1bKETsvwP5kW9u2ZBgJM20QLl8UvV9MZCHROqZBFnvWvvOTVmb5Bxa1g2t9zmAZDZD'
                      },
                      data : data
                    };
                    axios(config)
                    .then(function (response) {
                      console.log(JSON.stringify(response.data));
                    })
                    .catch(function (error) {
                      console.log(error);
                    });

                    setTimeout(return_temp1, 5000);
                     function return_temp1(){
                        var data = JSON.stringify({
                          "messaging_product": "whatsapp",
                          "recipient_type": "individual",
                          "to": "916383963540",
                          "type": "template",
                          "template": {
                            "name": "testing_template",
                            "language": {
                              "code": "en_US"
                            },
                            "components": [
                              {
                                "type": "button",
                                "sub_type": "quick_reply",
                                "index": "0",
                                "parameters": [
                                  {
                                    "type": "payload",
                                    "payload": "aGlzIHRoaXMgaXMgY29v"
                                  }
                                ]
                              },
                              {
                                "type": "button",
                                "sub_type": "quick_reply",
                                "index": "1",
                                "parameters": [
                                  {
                                    "type": "payload",
                                    "payload": "9rwnB8RbYmPF5t2Mn09x4h"
                                  }
                                ]
                              },
                              {
                                "type": "button",
                                "sub_type": "quick_reply",
                                "index": "2",
                                "parameters": [
                                  {
                                    "type": "payload",
                                    "payload": "aGlzIHRoaXMgaXMgY29v"
                                  }
                                ]
                              }
                            ]
                          }
                        });
                      var config = {
                        method: 'post',
                        url: 'https://graph.facebook.com/v15.0/100411159563677/messages',
                        headers: { 
                          'Content-Type': 'application/json', 
                          'Authorization': 'Bearer EAATQpG7HUWUBALG4ZCqcKutVqY6ZCSePThwNijZBnRafaQTzp7Se7wgDZCbkhgKPlqPn1Aei2rZCHrFHfFontlkcPDLKn18rELdAaNeZBFynUEu4yWjBQT9bX6rwSYyJIA73ZCMZAZAIF5NmtxeT1bKETsvwP5kW9u2ZBgJM20QLl8UvV9MZCHROqZBFnvWvvOTVmb5Bxa1g2t9zmAZDZD'
                        },
                        data : data
                      };
                      console.log("api_button_data-->"+data);
                      axios(config)
                      .then(function (response) {
                        console.log(JSON.stringify(response.data));
                      })
                      .catch(function (error) {
                        console.log(error);
                      });
                       setTimeout(return_temp2, 1000);
                    }
                    function return_temp2(){
                      var data = JSON.stringify({
                        "messaging_product": "whatsapp",
                        "recipient_type": "individual",
                        "to": "916383963540",
                        "type": "interactive",
                        "interactive": {
                          "type": "button",
                          "body": {
                            "text": "For more options :"
                          },
                          "action": {
                            "buttons": [
                              {
                                "type": "reply",
                                "reply": {
                                  "id": "<UNIQUE_BUTTON_ID_1>",
                                  "title": "Newsletter"
                                }
                              },
                              {
                                "type": "reply",
                                "reply": {
                                  "id": "<UNIQUE_BUTTON_ID_2>",
                                  "title": "Other Queries"
                                }
                              }
                            ]
                          }
                        }
                      });
                      var config = {
                        method: 'post',
                        url: 'https://graph.facebook.com/v15.0/100411159563677/messages',
                        headers: { 
                          'Content-Type': 'application/json', 
                          'Authorization': 'Bearer EAATQpG7HUWUBALG4ZCqcKutVqY6ZCSePThwNijZBnRafaQTzp7Se7wgDZCbkhgKPlqPn1Aei2rZCHrFHfFontlkcPDLKn18rELdAaNeZBFynUEu4yWjBQT9bX6rwSYyJIA73ZCMZAZAIF5NmtxeT1bKETsvwP5kW9u2ZBgJM20QLl8UvV9MZCHROqZBFnvWvvOTVmb5Bxa1g2t9zmAZDZD'
                        },
                        data : data
                      };
                      axios(config)
                      .then(function (response) {
                        console.log(JSON.stringify(response.data));
                      })
                      .catch(function (error) {
                        console.log(error);
                      });
                    }
                  }
                  // greet_flag = true;
                  // greet_flag = false;    
              // }
            }
              // please change the flag statement here .......
           // greet_flag = true;
          // greet_flag = false;     
          console.log("greet_flag--> "+greet_flag)

    }
    res.sendStatus(200);
  } else {
    // Return a '404 Not Found' if event is not from a WhatsApp API
    res.sendStatus(404);
  }
});
// Accepts GET requests at the /webhook endpoint. You need this URL to setup webhook initially.
// info on verification request payload: https://developers.facebook.com/docs/graph-api/webhooks/getting-started#verification-requests
app.get("/webhook", (req, res) => {
  /**
   * UPDATE YOUR VERIFY TOKEN
   *This will be the Verify Token value when you set up webhook
   **/
  const verify_token = process.env.VERIFY_TOKEN;
  // Parse params from the webhook verification request
  let mode = req.query["hub.mode"];
  // console.log("MODE_IS: "+mode);
  let token = req.query["hub.verify_token"];
  // console.log("token_is: "+token);
  let challenge = req.query["hub.challenge"];
  // Check if a token and mode were sent
  if (mode && token) {
    // Check the mode and token sent are correct
    if (mode === "subscribe" && token === verify_token) {
      // Respond with 200 OK and challenge token from the request
      console.log("WEBHOOK_VERIFIED");
      res.status(200).send(challenge);
    } else {
      // Responds with '403 Forbidden' if verify tokens do not match
      res.sendStatus(403);
    }
  }
});