from flask import Flask, request
import json

app = Flask(__name__)

@app.route('/webhook',methods=['POST','GET'])
def listner():
    if request.method == 'POST':
        print("\n recived_data 1 -->",request.json)
        resData = request.json
        print("-->",resData['entry'][0]['changes'][0]['value']['messages'][0]['text'])
        return 'success', 200
    elif request.method == 'GET':
        print("\n received data: 2 -->", request.json)
        
        challenge = request.args.get('hub.challenge')
        print("\n Challenge",challenge)
        if challenge == None:
            return '',200
        else:
            return challenge
    else:
        return '',200

@app.route('/flask', methods=['GET','POST'])
def login():
    print('------ Hello -------')
    FlaskMsg = 'Welcome Flask'
    return FlaskMsg

@app.route('/', methods=['GET'])
def getWP():
    print("app get request")
    return "app get request"

if __name__ == '__main__':
    app.run(debug=True,port=1337)